﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NPC : MonoBehaviour
{
    public Text dialogo, continuar;
    public string[] frases;
    private int index;
    float velocidadeDaEscrita;

    void Start()
    {
        dialogo.enabled = false;
        continuar.enabled = false;
        dialogo.text = "";
        velocidadeDaEscrita = 0.01f;
    }

    
    void Update()
    {
        
    }

    IEnumerator Digitar()
    {
        if (index < frases.Length)
        {
            foreach (char letra in frases[index].ToCharArray())
            {
                dialogo.text += letra;

                yield return new WaitForSeconds(velocidadeDaEscrita);
            }
        }
    }


    public void ProximaFrase()
    {
        
        if(index <= frases.Length - 1)
        {            
            dialogo.text += "\n";
            StartCoroutine(Digitar());
            index++;
        }
        else
        {
            dialogo.text = "";
            continuar.enabled = false;
            index = 0;
        }
    }
    
    
    private void OnTriggerStay2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "cat")
        {
            continuar.text = "Clique para conversar";
            continuar.enabled = true;
            
            dialogo.enabled = true;
            StartCoroutine(Digitar());

        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "cat")
        {
            continuar.enabled = false;
            dialogo.enabled = false;
        }
    }
    
}
